import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <header className="absolute top-0 left-0 w-full z-20">
      <nav className="max-w-6xl mx-auto flex items-center justify-between px-6 py-5 text-xs md:text-sm">
        <a
          href="#home"
          className="font-heading text-lg tracking-[0.25em] text-white"
        >
          CHO
        </a>
        <ul className="flex items-center gap-4 md:gap-6 text-white/90">
          <li><a href="#bestsellers" className="hover:text-white">Best seller</a></li>
          <li><Link to="/products" className="hover:text-white">Shop</Link></li>
          <li><Link to="/cart" className="hover:text-white">Cart</Link></li>
          <li><Link to="/auth" className="hover:text-white">Login</Link></li>
        </ul>
      </nav>
    </header>
  );
}
