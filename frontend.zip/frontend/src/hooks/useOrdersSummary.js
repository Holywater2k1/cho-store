import { useEffect, useState } from "react";
import { supabase } from "../lib/supabaseClient";
import { useAuth } from "../context/AuthContext";

export default function useOrdersSummary() {
  const { user } = useAuth();
  const [pendingOrdersCount, setPendingOrdersCount] = useState(0);

  useEffect(() => {
    if (!user) {
      setPendingOrdersCount(0);
      return;
    }

    const load = async () => {
      const { count, error } = await supabase
        .from("orders")
        .select("id", { count: "exact", head: true })
        .eq("user_id", user.id)
        // ignore history statuses
        .not("status", "in", "(accepted,lost,refund_requested)");

      if (!error && typeof count === "number") {
        setPendingOrdersCount(count);
      } else if (error) {
        console.error("Failed to load orders summary:", error.message);
      }
    };

    load();
  }, [user]);

  return { pendingOrdersCount };
}
