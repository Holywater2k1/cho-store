import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "../lib/supabaseClient";
import { useAuth } from "../context/AuthContext";

export default function OrdersPage() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [savingId, setSavingId] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!user) return;

    const load = async () => {
      setLoading(true);
      setError("");
      const { data, error } = await supabase
        .from("orders")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (error) {
        console.error(error);
        setError("Failed to load orders.");
      } else {
        setOrders(data || []);
      }
      setLoading(false);
    };

    load();
  }, [user]);

  const refreshOrders = async () => {
    if (!user) return;
    const { data, error } = await supabase
      .from("orders")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });

    if (!error) setOrders(data || []);
  };

  const updateStatus = async (orderId, status, extra = {}) => {
    setSavingId(orderId);
    setError("");
    try {
      const { error } = await supabase
        .from("orders")
        .update({ status, ...extra })
        .eq("id", orderId);

      if (error) throw error;
      await refreshOrders();
    } catch (err) {
      console.error(err);
      setError("Failed to update order. Please try again.");
    } finally {
      setSavingId(null);
    }
  };

  // user confirms they are happy
  const handleAccept = (order) => {
    updateStatus(order.id, "accepted", {
      completed_at: new Date().toISOString(),
    });
  };

  // go to “never accepted” form
  const handleNeverReceived = (order) => {
    navigate(`/orders/${order.id}/issue`);
  };

  // go to refund form
  const handleRefund = (order) => {
    navigate(`/orders/${order.id}/refund`);
  };

  // active orders: everything that is NOT final
  const activeOrders = orders.filter(
    (o) =>
      o.status !== "accepted" &&
      o.status !== "lost" &&
      o.status !== "refund_requested"
  );

  // history: only final states
  const historyOrders = orders.filter(
    (o) =>
      o.status === "accepted" ||
      o.status === "lost" ||
      o.status === "refund_requested"
  );

  return (
    <main className="min-h-screen bg-choSand pt-20">
      <div className="max-w-5xl mx-auto px-4 py-8">
        <h1 className="font-heading text-2xl mb-2">Your orders</h1>
        <p className="text-xs text-gray-600 mb-4">
          Track your previous purchases and see what&apos;s on the way.
        </p>

        {error && (
          <p className="mb-3 text-xs text-red-700 bg-red-50 border border-red-100 rounded-lg px-3 py-2">
            {error}
          </p>
        )}

        {loading && <p className="text-sm text-gray-600">Loading...</p>}

        {/* ========= ACTIVE / CURRENT ========= */}
        {!!activeOrders.length && (
          <section className="space-y-3 mb-8">
            <h2 className="font-heading text-sm text-gray-700 mb-1">
              In progress
            </h2>

            {activeOrders.map((order) => (
              <article
                key={order.id}
                className="bg-white rounded-2xl px-5 py-4 shadow-sm flex flex-col md:flex-row md:items-center md:justify-between gap-3"
              >
                <div>
                  <p className="text-[0.65rem] text-gray-500 mb-1">
                    #{order.id.slice(0, 8)} ·{" "}
                    {new Date(order.created_at).toLocaleString()}
                  </p>
                  <p className="text-sm font-semibold mb-1">
                    {order.full_name} · {order.city}, {order.province}
                  </p>
                  <p className="text-xs text-gray-600">
                    {order.address_line1}
                  </p>
                </div>

                <div className="text-right space-y-2">
                  <p className="text-sm font-semibold">
                    {order.total_amount} THB
                  </p>

                  {/* status pill */}
                  <p className="inline-flex items-center rounded-full border border-choForest/20 text-[0.7rem] px-3 py-1 text-choForest bg-choSand/50">
                    {order.status === "pending" && "Pending"}
                    {order.status === "preparing" && "Preparing"}
                    {order.status === "shipped" && "On the way"}
                    {order.status === "delivered" && "Delivered"}
                    {order.status === "completed" &&
                      "Delivered – please confirm"}
                    {["pending", "preparing", "shipped", "delivered", "completed"].indexOf(
                      order.status
                    ) === -1 && order.status}
                  </p>

                  {/* DELIVERY PROOF (if admin uploaded) */}
                  {order.delivery_proof_url && (
                    <button
                      type="button"
                      onClick={() =>
                        window.open(order.delivery_proof_url, "_blank")
                      }
                      className="block ml-auto text-[0.7rem] text-choForest underline underline-offset-2"
                    >
                      View delivery proof
                    </button>
                  )}

                  {/* ACTION BUTTONS – only when status is completed */}
                  {order.status === "completed" && (
                    <div className="mt-2 flex flex-wrap gap-2 justify-end text-xs">
                      <button
                        disabled={savingId === order.id}
                        onClick={() => handleAccept(order)}
                        className="rounded-full bg-choForest text-white px-3 py-1 disabled:opacity-60"
                      >
                        {savingId === order.id ? "Saving..." : "Accept"}
                      </button>

                      <button
                        disabled={savingId === order.id}
                        onClick={() => handleNeverReceived(order)}
                        className="rounded-full border border-gray-400 px-3 py-1 text-gray-700 disabled:opacity-60"
                      >
                        Never received
                      </button>

                      <button
                        disabled={savingId === order.id}
                        onClick={() => handleRefund(order)}
                        className="rounded-full border border-red-500 text-red-600 px-3 py-1 disabled:opacity-60"
                      >
                        Refund / return
                      </button>
                    </div>
                  )}
                </div>
              </article>
            ))}
          </section>
        )}

        {/* ========= HISTORY ========= */}
        <section className="space-y-3">
          <h2 className="font-heading text-sm text-gray-700 mb-1">
            History
          </h2>

          {historyOrders.length === 0 && (
            <p className="text-xs text-gray-500">
              You don&apos;t have any completed orders yet.
            </p>
          )}

          {historyOrders.map((order) => (
            <article
              key={order.id}
              className="bg-white rounded-2xl px-5 py-4 shadow-sm flex flex-col md:flex-row md:items-center md:justify-between gap-3"
            >
              <div>
                <p className="text-[0.65rem] text-gray-500 mb-1">
                  #{order.id.slice(0, 8)} ·{" "}
                  {new Date(order.created_at).toLocaleString()}
                </p>
                <p className="text-sm font-semibold mb-1">
                  {order.full_name} · {order.city}, {order.province}
                </p>
              </div>

              <div className="text-right space-y-1">
                <p className="text-sm font-semibold">
                  {order.total_amount} THB
                </p>

                {order.status === "accepted" && (
                  <span className="inline-flex items-center rounded-full bg-emerald-50 text-emerald-700 text-[0.7rem] px-3 py-1">
                    Delivered &amp; accepted
                  </span>
                )}
                {order.status === "lost" && (
                  <span className="inline-flex items-center rounded-full bg-amber-50 text-amber-700 text-[0.7rem] px-3 py-1">
                    Problem reported
                  </span>
                )}
                {order.status === "refund_requested" && (
                  <span className="inline-flex items-center rounded-full bg-red-50 text-red-600 text-[0.7rem] px-3 py-1">
                    Refund / return requested
                  </span>
                )}
              </div>
            </article>
          ))}
        </section>
      </div>
    </main>
  );
}
