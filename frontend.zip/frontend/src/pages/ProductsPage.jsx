import { useEffect, useState } from "react";
import { useCart } from "../context/CartContext";

const API_BASE = import.meta.env.VITE_API_BASE_URL;

export default function ProductsPage() {
  const [products, setProducts] = useState([]);
  const { addItem } = useCart();

  useEffect(() => {
    fetch(`${API_BASE}/api/products`)
      .then((r) => r.json())
      .then((data) => setProducts(data));
  }, []);

  return (
    <main className="min-h-screen bg-choSand">
      <div className="max-w-6xl mx-auto px-4 py-10">
        <h1 className="font-heading text-3xl mb-6">All candles</h1>
        <div className="grid gap-6 md:grid-cols-3">
          {products.map((p) => (
            <article key={p.id} className="bg-white rounded-xl p-5 shadow-sm flex flex-col">
              <div className="h-40 bg-choForest/10 mb-3" />
              <h2 className="font-heading text-xl">{p.name}</h2>
              <p className="text-sm text-gray-600 mb-1">{p.description}</p>
              <p className="text-xs uppercase tracking-wide text-gray-500 mb-3">
                {p.mood} • {p.size}
              </p>
              <div className="mt-auto flex items-center justify-between">
                <span className="font-semibold">{p.price} THB</span>
                <button
                  onClick={() => addItem(p, 1)}
                  className="text-xs border border-choForest rounded-full px-4 py-1 hover:bg-choForest hover:text-white"
                >
                  Add to cart
                </button>
              </div>
            </article>
          ))}
        </div>
      </div>
    </main>
  );
}
